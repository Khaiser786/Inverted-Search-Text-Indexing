#ifndef INVERTED_SEARCH_H
#define INVERTED_SEARCH_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#define FAILURE   -1
#define SUCCESS    0
#define FNAME_SIZE 15
#define WORD_SIZE 15
#define FILE_EMPTY -2
#define FILE_NOTAVAILABLE -3
#define REPEATATION -4

typedef struct file_node {
    char file_name[FNAME_SIZE];
    struct file_node *link;
} Flist;

typedef struct linkTable_node {
    int word_count;
    char file_name[FNAME_SIZE];
    struct linkTable_node *table_link;
} Ltable;

typedef struct word_node {
    int file_count;
    char word[WORD_SIZE];
    Ltable *Tlink;
    struct word_node *link;
} Wlist;

// File validation
void file_validation_n_file_list(Flist **f_head, char *argv[]);
int isFileEmpty(char *filename);
int to_create_list_of_files(Flist **f_head, char *name);

// Database operations
void create_database(Flist *f_head, Wlist *head[]);
void display_database(Wlist *head[]);
int update_database(Wlist *head[], Flist **f_head);
int search(Wlist *head, char *word);
int save_database(Wlist *head[]);

// Word list operations
int insert_at_last(Wlist **head, char *data);
int update_link_table(Wlist *head);

#endif
