#include "inverted_Search.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

extern char *file_name;  // global variable to track current file

// Helper to insert word into the database
static void add_word_to_database(Wlist **head, char *word, char *file_name)
{
    int index = tolower(word[0]) - 'a';
    if (index < 0 || index > 25) index = 26; // non-alphabet bucket

    Wlist *temp = head[index];
    while (temp)
    {
        if (strcmp(temp->word, word) == 0)
        {
            // Word already exists, update link table
            Ltable *lt = temp->Tlink;
            while (lt)
            {
                if (strcmp(lt->file_name, file_name) == 0)
                {
                    lt->word_count++;
                    return;
                }
                lt = lt->table_link;
            }
            // File not found in link table, add new entry
            Ltable *new_lt = malloc(sizeof(Ltable));
            strcpy(new_lt->file_name, file_name);
            new_lt->word_count = 1;
            new_lt->table_link = temp->Tlink;
            temp->Tlink = new_lt;
            temp->file_count++;
            return;
        }
        temp = temp->link;
    }

    // Word not found, create new node
    Wlist *new_word = malloc(sizeof(Wlist));
    strcpy(new_word->word, word);
    new_word->file_count = 1;
    new_word->link = head[index];
    new_word->Tlink = NULL;

    Ltable *new_lt = malloc(sizeof(Ltable));
    strcpy(new_lt->file_name, file_name);
    new_lt->word_count = 1;
    new_lt->table_link = NULL;
    new_word->Tlink = new_lt;

    head[index] = new_word;
}

// Main function to create database
void create_database(Flist *f_head, Wlist *head[])
{
    Flist *temp = f_head;
    FILE *fp;
    char word[WORD_SIZE];

    while (temp)
    {
        file_name = temp->file_name;  // set global file_name
        fp = fopen(temp->file_name, "r");
        if (fp == NULL)
        {
            printf("Error: Could not open file %s\n", temp->file_name);
            temp = temp->link;
            continue;
        }

        while (fscanf(fp, "%s", word) != EOF)
        {
            add_word_to_database(head, word, temp->file_name);
        }

        fclose(fp);
        temp = temp->link;
    }

    printf("Database created successfully.\n");
}
