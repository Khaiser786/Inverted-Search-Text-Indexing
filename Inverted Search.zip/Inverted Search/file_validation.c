#include "inverted_Search.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

// Validate files and build file list
void file_validation_n_file_list(Flist **f_head, char *argv[])
{
    int i = 1; // skip executable name
    int empty;

    while (argv[i] != NULL)
    {
        empty = isFileEmpty(argv[i]);
        if (empty == FILE_NOTAVAILABLE)
        {
            printf("File %s is not available\n", argv[i]);
            printf("Hence we are not adding that file into Linked List\n");
            i++;
            continue;
        }
        else if (empty == FILE_EMPTY)
        {
            printf("Contents of %s are empty\n", argv[i]);
            printf("Hence we are not adding that file into Linked List\n");
            i++;
            continue;
        }
        else
        {
            int ret_val = to_create_list_of_files(f_head, argv[i]);
            if (ret_val == SUCCESS)
            {
                printf("Successfully added %s file into Linked List\n", argv[i]);
                i++;
            }
            else if (ret_val == REPEATATION)
            {
                printf("File %s already present\n", argv[i]);
                i++;
            }
            else
            {
                printf("Something went wrong!\n");
                return;
            }
        }
    }
}

// Check file availability and content
int isFileEmpty(char *filename)
{
    FILE *fptr = fopen(filename, "r");
    if (fptr == NULL)
    {
        if (errno == ENOENT)
        {
            return FILE_NOTAVAILABLE;
        }
        return FILE_EMPTY;
    }

    fseek(fptr, 0, SEEK_END);
    if (ftell(fptr) == 0)
    {
        fclose(fptr);
        return FILE_EMPTY;
    }

    fclose(fptr);
    return SUCCESS;
}

// Create the file linked list
int to_create_list_of_files(Flist **f_head, char *name)
{
    Flist *temp = *f_head;
    Flist *newFile = malloc(sizeof(Flist));
    if (newFile == NULL)
        return FAILURE;

    strcpy(newFile->file_name, name);
    newFile->link = NULL;

    if (*f_head == NULL)
    {
        *f_head = newFile;
        return SUCCESS;
    }

    while (temp != NULL)
    {
        if (strcmp(temp->file_name, name) == 0)
        {
            free(newFile);
            return REPEATATION;
        }
        if (temp->link == NULL)
            break;
        temp = temp->link;
    }

    temp->link = newFile;
    return SUCCESS;
}
