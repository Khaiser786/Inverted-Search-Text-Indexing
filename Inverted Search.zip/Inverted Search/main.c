
#include "inverted_Search.h"
char *file_name;   // global definition
int main(int argc, char *argv[])
{
    int option;
    Wlist *head[27] = {NULL};

    if (argc <= 1)
    {
        printf("Usage: ./inverted_search.exe file1.txt file2.txt ...\n");
        return 0;
    }

    Flist *f_head = NULL;
    file_validation_n_file_list(&f_head, argv);

    if (f_head == NULL)
    {
        printf("No valid files found. Program terminated.\n");
        return -1;
    }

    do
    {
        printf("\n================ MENU ================\n");
        printf("1. Create Database\n");
        printf("2. Display Database\n");
        printf("3. Update Database\n");
        printf("4. Search Word\n");
        printf("5. Save & Exit\n");
        printf("======================================\n");
        printf("Enter your choice: ");
        scanf("%d", &option);

        switch (option)
        {
            case 1:
                create_database(f_head, head);
                break;
            case 2:
                display_database(head);
                break;
            case 3:
                update_database(head, &f_head);
                break;
            case 4:
            {
                char word[WORD_SIZE];
                printf("Enter word to search: ");
                scanf("%s", word);
                int index = tolower(word[0]) - 'a';
                if (index < 0 || index > 25) index = 26;
                search(head[index], word);
                break;
            }
            case 5:
                save_database(head);
                printf("Database saved. Exiting...\n");
                break;
            default:
                printf("Invalid choice. Try again.\n");
        }
    } while (option != 5);

    return 0;
}
