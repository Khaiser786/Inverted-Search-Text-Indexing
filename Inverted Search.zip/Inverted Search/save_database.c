#include "inverted_Search.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Save the inverted index database into a file
int save_database(Wlist *head[])
{
    FILE *fp = fopen("database.txt", "w");
    if (fp == NULL)
    {
        printf("Error: Could not open database.txt for writing.\n");
        return FAILURE;
    }

    for (int i = 0; i < 27; i++)
    {
        Wlist *temp = head[i];
        while (temp)
        {
            fprintf(fp, "Word: %s | Files: %d\n", temp->word, temp->file_count);

            Ltable *lt = temp->Tlink;
            while (lt)
            {
                fprintf(fp, "   -> File: %s | Count: %d\n", lt->file_name, lt->word_count);
                lt = lt->table_link;
            }

            temp = temp->link;
        }
    }

    fclose(fp);
    printf("Database successfully saved to database.txt\n");
    return SUCCESS;
}
