#include "inverted_Search.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Display the inverted index database
void display_database(Wlist *head[])
{
    printf("\n=========== DATABASE CONTENTS ===========\n");

    for (int i = 0; i < 27; i++)
    {
        Wlist *temp = head[i];
        if (temp == NULL)
            continue;

        while (temp)
        {
            printf("Word: %-15s | Files: %d\n", temp->word, temp->file_count);

            Ltable *lt = temp->Tlink;
            while (lt)
            {
                printf("   -> File: %-15s | Count: %d\n", lt->file_name, lt->word_count);
                lt = lt->table_link;
            }

            temp = temp->link;
        }
    }

    printf("=========================================\n");
}
