#include "inverted_Search.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Search for a word in the database
int search(Wlist *head, char *word)
{
    if (head == NULL)
    {
        printf("Database is empty. Please create the database first.\n");
        return FAILURE;
    }

    Wlist *temp = head;
    while (temp)
    {
        if (strcmp(temp->word, word) == 0)
        {
            printf("\nWord '%s' found in %d file(s):\n", word, temp->file_count);

            Ltable *lt = temp->Tlink;
            while (lt)
            {
                printf("   -> File: %-15s | Count: %d\n", lt->file_name, lt->word_count);
                lt = lt->table_link;
            }
            return SUCCESS;
        }
        temp = temp->link;
    }

    printf("\nWord '%s' not found in the database.\n", word);
    return FAILURE;
}
