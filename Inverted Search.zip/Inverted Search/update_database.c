#include "inverted_Search.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern char *file_name;  // global variable for current file

// Update the database with new files
int update_database(Wlist *head[], Flist **f_head)
{
    char filename[FNAME_SIZE];
    printf("Enter the new file name to add: ");
    scanf("%s", filename);

    // Validate the file
    int status = isFileEmpty(filename);
    if (status == FILE_NOTAVAILABLE)
    {
        printf("File %s not available.\n", filename);
        return FAILURE;
    }
    else if (status == FILE_EMPTY)
    {
        printf("File %s is empty.\n", filename);
        return FAILURE;
    }

    // Add file to file list
    int ret_val = to_create_list_of_files(f_head, filename);
    if (ret_val == REPEATATION)
    {
        printf("File %s already exists in the list.\n", filename);
        return FAILURE;
    }
    else if (ret_val == FAILURE)
    {
        printf("Error adding file %s to list.\n", filename);
        return FAILURE;
    }

    // Process the new file
    FILE *fp = fopen(filename, "r");
    if (fp == NULL)
    {
        printf("Error opening file %s.\n", filename);
        return FAILURE;
    }

    file_name = filename;  // set global file_name
    char word[WORD_SIZE];

    while (fscanf(fp, "%s", word) != EOF)
    {
        int index = tolower(word[0]) - 'a';
        if (index < 0 || index > 25) index = 26;

        Wlist *temp = head[index];
        int found = 0;

        while (temp)
        {
            if (strcmp(temp->word, word) == 0)
            {
                // Word exists, update link table
                Ltable *lt = temp->Tlink;
                while (lt)
                {
                    if (strcmp(lt->file_name, filename) == 0)
                    {
                        lt->word_count++;
                        found = 1;
                        break;
                    }
                    lt = lt->table_link;
                }
                if (!found)
                {
                    Ltable *new_lt = malloc(sizeof(Ltable));
                    strcpy(new_lt->file_name, filename);
                    new_lt->word_count = 1;
                    new_lt->table_link = temp->Tlink;
                    temp->Tlink = new_lt;
                    temp->file_count++;
                }
                found = 1;
                break;
            }
            temp = temp->link;
        }

        if (!found)
        {
            // Word not found, insert new
            insert_at_last(&head[index], word);
        }
    }

    fclose(fp);
    printf("Database updated successfully with file %s.\n", filename);
    return SUCCESS;
}
