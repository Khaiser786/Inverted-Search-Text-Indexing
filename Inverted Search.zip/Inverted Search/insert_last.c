#include "inverted_Search.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern char *file_name;  // current file being processed

// Insert a new word node at the end of the list
int insert_at_last(Wlist **head, char *data)
{
    // create the node
    Wlist *new = malloc(sizeof(Wlist));
    if (new == NULL)
        return FAILURE;

    // update the fields
    new->file_count = 1;
    strcpy(new->word, data);
    new->Tlink = NULL;
    new->link = NULL;

    // update link table for this word
    update_link_table(new);

    // if list is empty
    if (*head == NULL)
    {
        *head = new;
        return SUCCESS;
    }

    // if list is non-empty, go to last node
    Wlist *temp = *head;
    while (temp->link)
    {
        temp = temp->link;
    }
    temp->link = new;
    return SUCCESS;
}

// Create a link table entry for the word
int update_link_table(Wlist *head)
{
    Ltable *new = malloc(sizeof(Ltable));
    if (new == NULL)
        return FAILURE;

    new->word_count = 1;
    strcpy(new->file_name, file_name);
    new->table_link = NULL;

    head->Tlink = new;
    return SUCCESS;
}
